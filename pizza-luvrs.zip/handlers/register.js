module.exports = (req, h) => {
  return h.view('register')
}
